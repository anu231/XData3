package parsing;

import java.io.StringReader;

import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.parser.CCJSqlParserManager;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.select.AllColumns;
import net.sf.jsqlparser.statement.select.Join;
import net.sf.jsqlparser.statement.select.PlainSelect;
import net.sf.jsqlparser.statement.select.Select;
import net.sf.jsqlparser.statement.select.SelectExpressionItem;
import net.sf.jsqlparser.statement.select.SelectItem;

import java.util.*;

public class ParseSQL {

	private static Query query;
	private static CCJSqlParserManager pm;
	private static Statement stmt;
	private static TablesNamesFinder tnf;
	
	
	private static void parseQuery(String q, String qid) throws JSQLParserException{
		//int qid = 1;
		query = new Query(qid,q);
		pm = new CCJSqlParserManager();
		stmt = pm.parse(new StringReader(query.getQueryString()));
		System.out.println(q);
		if (stmt instanceof Select){
			//get the from list without going into subquery
			Select selectStatement = (Select) stmt;
			PlainSelect ps = (PlainSelect)selectStatement.getSelectBody();
			tnf.makeLists(selectStatement);
			List fromList = tnf.getFromList();
			List<SelectItem> projCols = tnf.getProjectedList();
			for (Iterator iter = fromList.iterator(); iter.hasNext();) {
				String fromItem = iter.next().toString();
				System.out.println(fromItem);
			}
			System.out.println("Projected Cols:");
			for (Iterator<SelectItem> iter = projCols.iterator(); iter.hasNext();) {
				SelectItem col = iter.next(); 
				if ( col instanceof AllColumns) {
					System.out.println("aal columns");
				} else if (col instanceof SelectExpressionItem){
					System.out.println("only 1111");
				}
				//String fromItem = iter.next().toString();
				System.out.println(col.toString());
			}
			System.out.println(tnf.getWhereClause());
		}
	}
	
	public static void main(String[] args)throws JSQLParserException {
		// TODO Auto-generated method stub
		String query = "Select a as d,count(s),v from moodle as m left outer join highland as h,jurassic as h where moodle.id=highland.id and jurassic.class=moodle.class";
		tnf = new TablesNamesFinder();
		parseQuery(query,"1");
		//CCJSqlParserManager pm = new CCJSqlParserManager(); 
		//Statement stmt = pm.parse(new StringReader(query));
		/*if (stmt instanceof Select) {
			Select selectStatement = (Select) stmt;
			PlainSelect ps = (PlainSelect)selectStatement.getSelectBody();
			List<SelectItem> l = ps.getSelectItems();
			//for ()
			System.out.println("from item :"+ps.getFromItem().toString());
			List<Join> j = ps.getJoins();
			System.out.println("right itms:");
			for (int i=0; i<j.size(); i++){
				Join temp = (Join)j.get(i);
				System.out.println(temp.getRightItem());
			}
			
			TablesNamesFinder tablesNamesFinder = new TablesNamesFinder();
			List tableList = tablesNamesFinder.getTableList(selectStatement);
			for (Iterator iter = tableList.iterator(); iter.hasNext();) {
				String tableName = iter.next().toString();
				System.out.println(tableName);
			}
			List tableAliasList = tablesNamesFinder.getTableAlias(selectStatement);
			for (Iterator iter = tableAliasList.iterator(); iter.hasNext();) {
				String tableName = iter.next().toString();
				System.out.println(tableName);
			}
		}*/
		
	}

}
