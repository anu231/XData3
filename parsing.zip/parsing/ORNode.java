package parsing;

import java.util.Vector;

public class ORNode {

	public ORNode(){
		andNodes = new Vector<ANDNode>();
		leafNodes = new Vector<Node>();
	}
	public Vector<ANDNode> andNodes;
	public Vector<Node> leafNodes;
	
	
}
